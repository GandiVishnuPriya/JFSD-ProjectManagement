package com.klef.jfsd.springboot.service;

import com.klef.jfsd.springboot.model.Project;

public interface ProjectService {
public 	Project addproject(Project project);
public Project viewproject(String leadname);
}
